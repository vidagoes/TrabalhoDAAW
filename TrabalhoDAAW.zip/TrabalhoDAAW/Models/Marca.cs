﻿namespace TrabalhoDAAW.Models
{
    public class Marca
    {

        public int Marcaid { get; set; }


        public string Nome { get; set; }
    }
}
